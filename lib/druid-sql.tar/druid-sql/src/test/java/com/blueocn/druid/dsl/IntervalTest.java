package com.blueocn.druid.dsl;

import java.util.Calendar;

import junit.framework.Assert;

import org.junit.Test;

import com.alibaba.fastjson.JSON;

public class IntervalTest {

    @Test
    public void test() {

        Calendar cal = Calendar.getInstance();

        cal.set(2015, 1, 20, 20, 20, 20);
        long start = cal.getTimeInMillis();

        cal.set(2015, 2, 20, 20, 20, 20);
        long end = cal.getTimeInMillis();

        Interval interval = new Interval(start, end);

        Assert.assertEquals("\"2015-02-20T12:20:20/2015-03-20T12:20:20\"", JSON.toJSONString(interval));
    }
}
