package com.blueocn.druid.compiler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import junit.framework.Assert;

import org.apache.commons.lang3.tuple.Pair;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.druid.JSONAssert;
import com.blueocn.druid.booleanExprs.BooleanExprAnd;
import com.blueocn.druid.booleanExprs.BooleanExprEq;
import com.blueocn.druid.booleanExprs.IBooleanExpr;
import com.blueocn.druid.dsl.granularities.SimpleGranularity;
import com.blueocn.druid.operands.AliasOprand;
import com.blueocn.druid.operands.LimitOprand;
import com.blueocn.druid.operands.NameOprand;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.operands.OrderByOprand;
import com.blueocn.druid.operands.binary.DividOprand;
import com.blueocn.druid.operands.math.SumOprand;
import com.blueocn.druid.operands.primitive.IntPrimitiveOprand;
import com.blueocn.druid.operands.primitive.StringPrimitiveOprand;
import com.blueocn.druid.parser.Query;

public class TopNCompilerTest {

    private TopNCompiler compiler;

    @Before
    public void setUp() {
        compiler = new TopNCompiler();
    }

    @Test
    public void testCanCompile() {
        Query query =
                Query.builder().orderBy(Arrays.asList(Mockito.mock(OrderByOprand.class))).limit(new LimitOprand(0, 1)).groupBys(Arrays.asList(Mockito.mock(Oprand.class))).build();
        Assert.assertTrue(compiler.canCompile(query));
    }

    @Test
    public void testCompile() {
        // timestamps:
        Calendar cal = Calendar.getInstance();
        cal.set(2015, 1, 20, 20, 20, 20);
        long start = cal.getTimeInMillis();
        cal.set(2015, 2, 20, 20, 20, 20);
        long end = cal.getTimeInMillis();

        Oprand avgOprand = new DividOprand(new SumOprand("longSume", new NameOprand(null, "num1")), new SumOprand("longSume", new NameOprand(null, "num2")));
        // selected columns:
        List<Oprand> columns = new ArrayList<Oprand>();
        columns.add(new AliasOprand(new SumOprand("longSume", new NameOprand(null, "num1")), "num1"));
        columns.add(new AliasOprand(avgOprand, "avg"));

        // order by
        OrderByOprand orderBy = new OrderByOprand(avgOprand, true);
        IBooleanExpr whereClause =
                new BooleanExprAnd(new BooleanExprEq(new NameOprand(null, "name"), new StringPrimitiveOprand("oneapm")), new BooleanExprEq(new NameOprand(null, "type"),
                        new IntPrimitiveOprand("10")));
        Query query =
                Query.builder().orderBy(Arrays.asList(orderBy)).limit(new LimitOprand(1, 10)).groupBys(Arrays.asList((Oprand) new NameOprand(null, "id")))
                        .granularity(new SimpleGranularity("all")).columns(columns).table("metric_table").timestamps(Pair.of(start, end)).whereClause(whereClause).build();

        Assert.assertTrue(compiler.canCompile(query));
        String json = compiler.compile(query);
        JSONObject jo = JSON.parseObject(json);
        JSONAssert.eq(jo, "queryType", "topN");
        JSONAssert.eq(jo, "dataSource", "metric_table");
        JSONAssert.eq(jo, "dimension", "id");
        JSONAssert.eq(jo, "threshold", 11);
        JSONAssert.eq(jo, "metric", "avg");
        JSONAssert.eq(jo, "granularity", "all");
        JSONAssert.exists(jo, "filter");
        JSONAssert.exists(jo, "aggregations");
        JSONAssert.exists(jo, "postAggregations");
        JSONAssert.exists(jo, "intervals");

    }
}
