package com.blueocn.druid.dsl.granularities;

import java.util.Calendar;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.druid.JSONAssert;

public class PeriodGranularityTest {

    @Test
    public void test() {
        Calendar cal = Calendar.getInstance();
        cal.set(2015, 1, 20, 20, 20, 20);
        long start = cal.getTimeInMillis();
        PeriodGranularity pg = new PeriodGranularity("PT30M", "America/Los_Angeles", start);
        String json = JSON.toJSONString(pg);
        JSONObject jo = JSON.parseObject(json);
        JSONAssert.eq(jo, "type", "period");
        JSONAssert.eq(jo, "period", "PT30M");
        JSONAssert.eq(jo, "timeZone", "America/Los_Angeles");
        JSONAssert.eq(jo, "origin", "2015-02-20T12:20:20");
    }

}
