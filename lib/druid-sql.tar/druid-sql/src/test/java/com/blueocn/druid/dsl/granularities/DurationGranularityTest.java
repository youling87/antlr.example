package com.blueocn.druid.dsl.granularities;

import java.util.Calendar;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.druid.JSONAssert;

public class DurationGranularityTest {

    @Test
    public void test() {
        Calendar cal = Calendar.getInstance();
        cal.set(2015, 1, 20, 20, 20, 20);
        long start = cal.getTimeInMillis();
        DurationGranularity dg = new DurationGranularity(10L, start);
        String json = JSON.toJSONString(dg);
        JSONObject jo = JSON.parseObject(json);
        JSONAssert.eq(jo, "type", "duration");
        JSONAssert.eq(jo, "duration", 10);
        JSONAssert.eq(jo, "origin", "2015-02-20T12:20:20");
    }

}
