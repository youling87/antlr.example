package com.blueocn.druid.parser;

import static org.junit.Assert.*;

import org.junit.Test;

import com.blueocn.druid.booleanExprs.BooleanExprAnd;
import com.blueocn.druid.booleanExprs.BooleanExprEq;
import com.blueocn.druid.booleanExprs.BooleanExprOr;
import com.blueocn.druid.operands.AliasOprand;
import com.blueocn.druid.operands.LimitOprand;
import com.blueocn.druid.operands.NameOprand;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.operands.OrderByOprand;
import com.blueocn.druid.operands.binary.AddOprand;
import com.blueocn.druid.operands.binary.DividOprand;
import com.blueocn.druid.operands.binary.MinusOprand;
import com.blueocn.druid.operands.binary.MultiplyOprand;
import com.blueocn.druid.operands.math.SumOprand;
import com.blueocn.druid.operands.primitive.FloatPrimitiveOprand;
import com.blueocn.druid.operands.primitive.IntPrimitiveOprand;
import com.blueocn.druid.operands.primitive.StringPrimitiveOprand;

public class ParserEngineTest {


    /**
     * 测试基础的select语句
     */
    @Test
    public void baseSelectTest() {
        String sql =
                "select aaa,sss.bbb,abc as abcd,longSum(abcd) AS ss,longSum(abc) as uh,( doubleSum(abcd) / 3.6 ) as hj,(doubleSum(aaa)+3.6*(4.5/abc)-def) as iu from table_name";
        Query query = ParserEngine.parse(sql);
        assertNotNull(query);
        assertEquals(query.getTable(), "table_name");
        assertArrayEquals(query.getColumns().toArray(), new Oprand[] {
                        new NameOprand("table_name", "aaa"),
                        new NameOprand("sss", "bbb"),
                        new AliasOprand(new NameOprand("table_name", "abc"), "abcd"),
                        new AliasOprand(new SumOprand("longSum", new NameOprand("table_name", "abcd")), "ss"),
                        new AliasOprand(new SumOprand("longSum", new NameOprand("table_name", "abc")), "uh"),
                        new AliasOprand(new DividOprand(new SumOprand("doubleSum", new NameOprand("table_name", "abcd")), new FloatPrimitiveOprand("3.6")) {}, "hj"),
                        new AliasOprand(new MinusOprand(new AddOprand(new SumOprand("doubleSum", new NameOprand("table_name", "aaa")), new MultiplyOprand(new FloatPrimitiveOprand(
                                "3.6"), new DividOprand(new FloatPrimitiveOprand("4.5"), new NameOprand("table_name", "abc")))), new NameOprand("table_name", "def")), "iu")});

    }

    @Test
    public void whereTest() {
        long startTime = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();
        String sql = "select aaa from bbb wherE timestamps between " + startTime + " and " + endTime + " and (aaa=\'aaaa\' or (longsum(bbb)=2015 and doubleSum(ddd)=2015.54))";
        Query query = ParserEngine.parse(sql);
        assertNotNull(query);
        assertEquals(query.getTable(), "bbb");
        assertEquals(query.getWhereClause(), new BooleanExprOr(new BooleanExprEq(new NameOprand("bbb", "aaa"), new StringPrimitiveOprand("aaaa")), new BooleanExprAnd(
                new BooleanExprEq(new SumOprand("longSum", new NameOprand("bbb", "bbb")), new IntPrimitiveOprand("2015")), new BooleanExprEq(new SumOprand("doubleSum",
                        new NameOprand("bbb", "ddd")), new FloatPrimitiveOprand("2015.54")))));
    }

    @Test
    public void groupByTest() {
        String sql = "select aaa from bbb group by ccc,longsum(ddd),longsum(eee)/doublesum(aaa),longsum(ddd)/sss*(longsum(www)+doublesum(sss))";

        Query query = ParserEngine.parse(sql);
        assertNotNull(query);
        assertEquals(query.getTable(), "bbb");
        assertArrayEquals(query.getGroupBys().toArray(), new Oprand[] {
                        new NameOprand("bbb", "ccc"),
                        new SumOprand("longSum", new NameOprand("bbb", "ddd")),
                        new DividOprand(new SumOprand("longSum", new NameOprand("bbb", "eee")), new SumOprand("doubleSum", new NameOprand("bbb", "aaa"))),
                        new MultiplyOprand(new DividOprand(new SumOprand("longSum", new NameOprand("bbb", "ddd")), new NameOprand("bbb", "sss")), new AddOprand(new SumOprand(
                                "longSum", new NameOprand("bbb", "www")), new SumOprand("doubleSum", new NameOprand("bbb", "sss"))))});

    }

    @Test
    public void orderByTest() {
        String sql = "select aaa from bbb order by aaa desc,longsum(aaa) ,longsum(aaa)/5 asc";
        Query query = ParserEngine.parse(sql);
        System.out.println(query);
        assertNotNull(query);
        assertArrayEquals(query.getOrderBy().toArray(), new OrderByOprand[] {new OrderByOprand(new NameOprand("bbb", "aaa"), true),
                        new OrderByOprand(new SumOprand("longSum", new NameOprand("bbb", "aaa")), false),
                        new OrderByOprand(new DividOprand(new SumOprand("longSum", new NameOprand("bbb", "aaa")), new IntPrimitiveOprand("5")), false)});
    }

    public void limitTest() {
        String sql = "select aaa from bbb  limit 0,5";
        Query query = ParserEngine.parse(sql);
        assertNotNull(query);
        LimitOprand limitOprand = query.getLimit();
        assertEquals(limitOprand.getOffeset(), 0);
        assertEquals(limitOprand.getMaxSize(), 5);
        sql = "select aaa from bbb limit 10,5";
        limitOprand = query.getLimit();
        assertEquals(limitOprand.getOffeset(), 10);
        assertEquals(limitOprand.getMaxSize(), 5);
    }
    
}
