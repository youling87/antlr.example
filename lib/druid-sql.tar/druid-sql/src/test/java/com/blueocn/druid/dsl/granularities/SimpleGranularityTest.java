package com.blueocn.druid.dsl.granularities;

import junit.framework.Assert;

import org.junit.Test;

import com.alibaba.fastjson.JSON;

public class SimpleGranularityTest {

    @Test
    public void test() {
        SimpleGranularity sg = new SimpleGranularity("all");
        Assert.assertEquals("\"all\"", JSON.toJSONString(sg));
    }

}
