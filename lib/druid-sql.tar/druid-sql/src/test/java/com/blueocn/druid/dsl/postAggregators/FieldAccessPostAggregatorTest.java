package com.blueocn.druid.dsl.postAggregators;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.druid.JSONAssert;

public class FieldAccessPostAggregatorTest {

    @Test
    public void test() {
        FieldAccessPostAggregator agg = new FieldAccessPostAggregator("size");
        JSONObject jo = JSON.parseObject(JSON.toJSONString(agg));
        JSONAssert.eq(jo, "type", "fieldAccess");
        JSONAssert.eq(jo, "fieldName", "size");
    }

}
