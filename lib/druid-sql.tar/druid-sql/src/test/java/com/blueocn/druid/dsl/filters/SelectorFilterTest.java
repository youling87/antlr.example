package com.blueocn.druid.dsl.filters;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.druid.JSONAssert;
import com.blueocn.druid.dsl.filters.SelectorFilter;

public class SelectorFilterTest {

    @Test
    public void test() {

        SelectorFilter filter = new SelectorFilter("metric", "value");
        String json = JSON.toJSONString(filter);
        JSONObject jsonObj = JSON.parseObject(json);
        JSONAssert.eq(jsonObj, "dimension", "metric");
        JSONAssert.eq(jsonObj, "value", "value");
        JSONAssert.eq(jsonObj, "type", "selector");
    }

}
