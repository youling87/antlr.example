package com.blueocn.druid.dsl.postAggregators;

import java.util.Arrays;

import org.junit.Test;
import org.mockito.Mockito;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.druid.JSONAssert;
import com.blueocn.druid.dsl.aggregators.IAggregator;

public class ArithmeticPostAggregatorTest {

    @Test
    public void test() {
        ArithmeticPostAggregator agg = new ArithmeticPostAggregator("size", "/", Arrays.asList(Mockito.mock(IAggregator.class), Mockito.mock(IAggregator.class)));
        JSONObject jo = JSON.parseObject(JSON.toJSONString(agg));
        JSONAssert.eq(jo, "type", "arithmetic");
        JSONAssert.eq(jo, "name", "size");
        JSONAssert.exists(jo, "fields");
        // JSONAssert.exists(jo, "ordering");
    }

}
