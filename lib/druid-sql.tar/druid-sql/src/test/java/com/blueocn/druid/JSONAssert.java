package com.blueocn.druid;

import junit.framework.Assert;

import com.alibaba.fastjson.JSONObject;

public class JSONAssert {
    public static void eq(JSONObject json, String field, Object value) {
        Assert.assertTrue(json.containsKey(field));
        Assert.assertEquals(value, json.get(field));
    }

    public static void exists(JSONObject json, String field) {
        Assert.assertTrue(json.containsKey(field));
    }
}
