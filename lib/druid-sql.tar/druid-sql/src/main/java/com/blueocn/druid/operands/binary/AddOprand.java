package com.blueocn.druid.operands.binary;

import com.blueocn.druid.operands.Oprand;

public class AddOprand extends BinaryOprand {

    public AddOprand(Oprand left, Oprand right) {
        super(left, right, "+");
    }

}
