package com.blueocn.druid.operands.binary;

import java.util.Arrays;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.postAggregators.ArithmeticPostAggregator;
import com.blueocn.druid.operands.Oprand;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public abstract class BinaryOprand implements Oprand {
    private final Oprand left;
    private final Oprand right;
    private final String oprator;

    @Override
    public IAggregator getAggregator() {
        return new ArithmeticPostAggregator(null, oprator, Arrays.asList(left.getAggregator(), right.getAggregator()));
    }

}
