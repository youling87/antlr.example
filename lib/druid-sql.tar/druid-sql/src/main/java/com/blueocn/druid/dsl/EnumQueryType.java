package com.blueocn.druid.dsl;

public enum EnumQueryType {
    topN, timeseries, groupBy;
}
