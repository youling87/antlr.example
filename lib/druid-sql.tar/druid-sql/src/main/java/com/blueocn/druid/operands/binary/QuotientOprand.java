package com.blueocn.druid.operands.binary;

import com.blueocn.druid.operands.Oprand;

/**
 * quotient division behaves like regular floating point division <br>
 * {@link http://druid.io/docs/0.8.0/querying/post-aggregations.html}
 * 
 * @author zhxiaog
 *
 */
public class QuotientOprand extends BinaryOprand {

    public QuotientOprand(Oprand left, Oprand right) {
        super(left, right, "quotient");
    }

}
