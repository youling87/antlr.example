package com.blueocn.druid.operands.primitive;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.postAggregators.ConstPostAggregator;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class IntPrimitiveOprand implements PrimitiveOprand {

    private final String value;

    @Override
    public IAggregator getAggregator() {
        return new ConstPostAggregator(null, value);
    }


}
