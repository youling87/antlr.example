package com.blueocn.druid.dsl.filters;


public interface Filter {
    public String getType();
}
