package com.blueocn.druid.operands;

import com.blueocn.druid.dsl.aggregators.IAggregator;

public interface Oprand {
    IAggregator getAggregator();
}
