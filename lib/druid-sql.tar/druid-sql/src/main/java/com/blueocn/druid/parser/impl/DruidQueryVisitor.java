package com.blueocn.druid.parser.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import lombok.Getter;

import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.RuleNode;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.apache.commons.lang3.tuple.Pair;

import com.blueocn.druid.booleanExprs.BooleanExprAnd;
import com.blueocn.druid.booleanExprs.BooleanExprEq;
import com.blueocn.druid.booleanExprs.BooleanExprOr;
import com.blueocn.druid.booleanExprs.IBooleanExpr;
import com.blueocn.druid.dsl.granularities.DurationGranularity;
import com.blueocn.druid.dsl.granularities.Granularity;
import com.blueocn.druid.dsl.granularities.PeriodGranularity;
import com.blueocn.druid.dsl.granularities.SimpleGranularity;
import com.blueocn.druid.operands.AliasOprand;
import com.blueocn.druid.operands.LimitOprand;
import com.blueocn.druid.operands.NameOprand;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.operands.OrderByOprand;
import com.blueocn.druid.operands.binary.AddOprand;
import com.blueocn.druid.operands.binary.DividOprand;
import com.blueocn.druid.operands.binary.MinusOprand;
import com.blueocn.druid.operands.binary.MultiplyOprand;
import com.blueocn.druid.operands.binary.QuotientOprand;
import com.blueocn.druid.operands.primitive.FloatPrimitiveOprand;
import com.blueocn.druid.operands.primitive.IntPrimitiveOprand;
import com.blueocn.druid.operands.primitive.StringPrimitiveOprand;
import com.blueocn.druid.parser.DruidLexer;
import com.blueocn.druid.parser.DruidQuery.AddNameContext;
import com.blueocn.druid.parser.DruidQuery.AggregationNameContext;
import com.blueocn.druid.parser.DruidQuery.AndOprContext;
import com.blueocn.druid.parser.DruidQuery.BoolExprContext;
import com.blueocn.druid.parser.DruidQuery.ColumListContext;
import com.blueocn.druid.parser.DruidQuery.ColumnNameContext;
import com.blueocn.druid.parser.DruidQuery.DurationGranContext;
import com.blueocn.druid.parser.DruidQuery.EqOprContext;
import com.blueocn.druid.parser.DruidQuery.FloatEleContext;
import com.blueocn.druid.parser.DruidQuery.GranularityCluasterContext;
import com.blueocn.druid.parser.DruidQuery.GranularityExprContext;
import com.blueocn.druid.parser.DruidQuery.GroupCluasterContext;
import com.blueocn.druid.parser.DruidQuery.IdEleContext;
import com.blueocn.druid.parser.DruidQuery.IdentityContext;
import com.blueocn.druid.parser.DruidQuery.IntEleContext;
import com.blueocn.druid.parser.DruidQuery.LRNameContext;
import com.blueocn.druid.parser.DruidQuery.LimitCluasterContext;
import com.blueocn.druid.parser.DruidQuery.LrExprContext;
import com.blueocn.druid.parser.DruidQuery.MulNameContext;
import com.blueocn.druid.parser.DruidQuery.NameContext;
import com.blueocn.druid.parser.DruidQuery.NameOprContext;
import com.blueocn.druid.parser.DruidQuery.NameOprandContext;
import com.blueocn.druid.parser.DruidQuery.OrOprContext;
import com.blueocn.druid.parser.DruidQuery.OrderCluasterContext;
import com.blueocn.druid.parser.DruidQuery.OrderContext;
import com.blueocn.druid.parser.DruidQuery.PeriodGranContext;
import com.blueocn.druid.parser.DruidQuery.ProgContext;
import com.blueocn.druid.parser.DruidQuery.SimpleGranContext;
import com.blueocn.druid.parser.DruidQuery.StringEleContext;
// import com.blueocn.druid.parser.DruidQuery.StringEleContext;
import com.blueocn.druid.parser.DruidQuery.TableRefContext;
import com.blueocn.druid.parser.DruidQuery.TimestampsContext;
import com.blueocn.druid.parser.DruidQuery.WhereCluasterContext;
import com.blueocn.druid.parser.Query;
import com.blueocn.druid.parser.funcation.FuncationManager;

public class DruidQueryVisitor implements com.blueocn.druid.parser.DruidQueryVisitor<Boolean> {

    private Stack<Object>      stack;

    @Getter
    private Query              query;


    private Query.QueryBuilder builder;

    private String             defaultTableName;

    public DruidQueryVisitor() {
        stack = new Stack<Object>();
        builder = Query.builder();
    }


    @Override
    public Boolean visit(ParseTree parseTree) {
        if (parseTree instanceof ProgContext) {
            if (visitProg((ProgContext) parseTree)) {
                query = builder.build();
                return true;
            }
        }
        return false;
    }

    @Override
    public Boolean visitChildren(RuleNode arg0) {
        return null;
    }

    @Override
    public Boolean visitErrorNode(ErrorNode arg0) {
        return false;
    }

    @Override
    public Boolean visitTerminal(TerminalNode arg0) {
        return null;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Boolean visitProg(ProgContext ctx) {
        if (ctx.tableRef() != null) {
            if (!visitTableRef(ctx.tableRef()))
                return false;
            builder.table(String.valueOf(stack.pop()));
        }
        if (ctx.columList() != null) {
            if (!visitColumList(ctx.columList())) {
                return false;
            }
            builder.columns((List<Oprand>) stack.pop());
        }

        if (ctx.whereCluaster() != null) {
            if (!visitWhereCluaster(ctx.whereCluaster())) {
                return false;
            }
            builder.whereClause((IBooleanExpr) stack.pop());
        }

        if (ctx.groupCluaster() != null) {
            if (!visitGroupCluaster(ctx.groupCluaster())) {
                return false;
            }
            builder.groupBys((List<Oprand>) stack.pop());
        }
        if (ctx.orderCluaster() != null) {
            if (!visitOrderCluaster(ctx.orderCluaster())) {
                return false;
            }
            builder.orderBy((List<OrderByOprand>) stack.pop());
        }
        if (ctx.limitCluaster() != null) {
            if (!visitLimitCluaster(ctx.limitCluaster())) {
                return false;
            }
            builder.limit((LimitOprand) stack.pop());

        }
        if (ctx.granularityCluaster() == null) {
            builder.granularity(new SimpleGranularity("all"));
        } else {
            if (!visitGranularityCluaster(ctx.granularityCluaster())) {
                return false;
            }
            builder.granularity((Granularity) stack.pop());
        }
        return true;
    }

    @Override
    public Boolean visitColumList(ColumListContext ctx) {
        List<Oprand> oprands = new ArrayList<Oprand>();
        List<NameOprandContext> list = ctx.nameOprand();
        for (NameOprandContext nameOprandContext : list) {
            if (!visitNameOprand(nameOprandContext)) {
                return false;
            }
            Oprand oprand = (Oprand) stack.pop();
            oprands.add(oprand);
        }
        stack.push(oprands);
        return true;
    }

    @Override
    public Boolean visitNameOprand(NameOprandContext ctx) {
        // 备份现场
        stack.push(defaultTableName);
        if (ctx.tableName != null) {
            defaultTableName = ctx.tableName.getText();
        }
        if (visitName(ctx.columnName)) {
            Oprand inOprand = (Oprand) stack.pop();
            defaultTableName = String.valueOf(stack.pop());

            if (ctx.alias != null) {
                stack.push(new AliasOprand(inOprand, ctx.alias.getText()));
            } else {
                stack.push(inOprand);
            }
            return true;
        }
        return false;
    }

    @Override
    public Boolean visitTableRef(TableRefContext ctx) {
        this.defaultTableName = ctx.tableName.getText();
        stack.push(defaultTableName);
        return true;
    }

    @Override
    public Boolean visitWhereCluaster(WhereCluasterContext ctx) {
        if (visitTimestamps(ctx.timestamps())) {
            return visitBoolExpr(ctx.boolExpr());
        }
        return false;
    }


    @Override
    public Boolean visitTimestamps(TimestampsContext ctx) {
        builder.timestamps(Pair.<Long, Long>of(Long.valueOf(ctx.left.getText()), Long.valueOf(ctx.left.getText())));
        return true;
    }

    public Boolean visitBoolExpr(BoolExprContext ctx) {
        if (ctx instanceof LrExprContext) {
            return visitLrExpr((LrExprContext) ctx);
        } else if (ctx instanceof EqOprContext) {
            return visitEqOpr((EqOprContext) ctx);
        } else if (ctx instanceof AndOprContext) {
            return visitAndOpr((AndOprContext) ctx);
        } else if (ctx instanceof OrOprContext) {
            return visitOrOpr((OrOprContext) ctx);
        } else if (ctx instanceof NameOprContext) {
            return visitNameOpr((NameOprContext) ctx);
        }
        return false;
    }

    @Override
    public Boolean visitLrExpr(LrExprContext ctx) {
        return visitBoolExpr(ctx.boolExpr());
    }

    @Override
    public Boolean visitEqOpr(EqOprContext ctx) {
        if (visitBoolExpr(ctx.left)) {
            Oprand left = (Oprand) stack.pop();
            if (visitBoolExpr(ctx.right)) {
                Oprand right = (Oprand) stack.pop();
                stack.push(new BooleanExprEq(left, right));
                return true;
            }
        }
        return false;
    }

    @Override
    public Boolean visitAndOpr(AndOprContext ctx) {
        if (visitBoolExpr(ctx.left)) {
            IBooleanExpr left = (IBooleanExpr) stack.pop();
            if (visitBoolExpr(ctx.right)) {
                IBooleanExpr right = (IBooleanExpr) stack.pop();
                stack.push(new BooleanExprAnd(left, right));
                return true;
            }
        }
        return false;
    }

    @Override
    public Boolean visitOrOpr(OrOprContext ctx) {
        if (visitBoolExpr(ctx.left)) {
            IBooleanExpr left = (IBooleanExpr) stack.pop();
            if (visitBoolExpr(ctx.right)) {
                IBooleanExpr right = (IBooleanExpr) stack.pop();
                stack.push(new BooleanExprOr(left, right));
                return true;
            }
        }
        return false;
    }

    @Override
    public Boolean visitNameOpr(NameOprContext ctx) {
        return visitName(ctx.name());
    }

    @Override
    public Boolean visitGroupCluaster(GroupCluasterContext ctx) {
        List<Oprand> groupBys = new ArrayList<Oprand>();
        List<NameContext> names = ctx.name();
        for (NameContext name : names) {
            if (!visitName(name)) {
                return false;
            }
            Oprand inOprand = (Oprand) stack.pop();
            groupBys.add(inOprand);
        }
        stack.push(groupBys);
        return true;
    }

    @Override
    public Boolean visitOrderCluaster(OrderCluasterContext ctx) {

        List<OrderByOprand> orderbys = new ArrayList<OrderByOprand>();
        List<OrderContext> orders = ctx.order();
        for (OrderContext orderContext : orders) {
            if (!visitOrder(orderContext)) {
                return false;
            }
            OrderByOprand inOprand = (OrderByOprand) stack.pop();
            orderbys.add(inOprand);
        }
        stack.push(orderbys);
        return true;
    }



    @Override
    public Boolean visitOrder(OrderContext ctx) {
        boolean isDesc = false;
        if (ctx.type != null) {
            isDesc = ctx.type.getType() == DruidLexer.DESC;
        }
        if (visitName(ctx.name())) {
            stack.push(new OrderByOprand((Oprand) stack.pop(), isDesc));
            return true;
        }
        return false;
    }

    @Override
    public Boolean visitLimitCluaster(LimitCluasterContext ctx) {
        int offset = 0;
        int resultCount = Integer.valueOf(ctx.resultCount.getText());
        if (ctx.offset != null) {
            offset = Integer.valueOf(ctx.offset.getText());
        }
        stack.push(new LimitOprand(offset, resultCount));
        return true;
    }

    public Boolean visitName(NameContext ctx) {
        if (ctx instanceof LRNameContext) {
            return visitLRName((LRNameContext) ctx);
        } else if (ctx instanceof MulNameContext) {
            return visitMulName((MulNameContext) ctx);
        } else if (ctx instanceof AddNameContext) {
            return visitAddName((AddNameContext) ctx);
        } else if (ctx instanceof AggregationNameContext) {
            return visitAggregationName((AggregationNameContext) ctx);
        } else if (ctx instanceof ColumnNameContext) {
            return visitColumnName((ColumnNameContext) ctx);
        }
        return false;
    }

    @Override
    public Boolean visitLRName(LRNameContext ctx) {
        return visitName(ctx.name());
    }

    @Override
    public Boolean visitMulName(MulNameContext ctx) {
        if (visitName(ctx.left)) {
            Oprand left = (Oprand) stack.pop();
            if (visitName(ctx.right)) {
                Oprand right = (Oprand) stack.pop();
                int type = ctx.op.getType();
                switch (type) {
                    case DruidLexer.STAR:
                        stack.push(new MultiplyOprand(left, right));
                        return true;
                    case DruidLexer.SLASH:
                        stack.push(new DividOprand(left, right));
                        return true;
                    case DruidLexer.MOD:
                        stack.push(new QuotientOprand(left, right));
                        return true;
                }
            }
        }
        return false;
    }

    @Override
    public Boolean visitAddName(AddNameContext ctx) {
        if (visitName(ctx.left)) {
            Oprand left = (Oprand) stack.pop();
            if (visitName(ctx.right)) {
                Oprand right = (Oprand) stack.pop();
                int type = ctx.op.getType();
                switch (type) {
                    case DruidLexer.PLUS:
                        stack.push(new AddOprand(left, right));
                        return true;
                    case DruidLexer.SUB:
                        stack.push(new MinusOprand(left, right));
                        return true;
                }
            }
        }
        return false;
    }

    @Override
    public Boolean visitColumnName(ColumnNameContext ctx) {
        IdentityContext identity = ctx.identity();
        if (identity instanceof IdEleContext) {
            return visitIdEle((IdEleContext) identity);
        } else if (identity instanceof IntEleContext) {
            return visitIntEle((IntEleContext) identity);
        } else if (identity instanceof FloatEleContext) {
            return visitFloatEle((FloatEleContext) identity);
        } else if (identity instanceof StringEleContext) {
            return visitStringEle((StringEleContext) identity);
        }
        return false;
    }


    @Override
    public Boolean visitIdEle(IdEleContext ctx) {
        stack.push(new NameOprand(defaultTableName, ctx.ID().getText()));
        return true;
    }


    @Override
    public Boolean visitIntEle(IntEleContext ctx) {
        stack.push(new IntPrimitiveOprand(ctx.getText()));
        return true;
    }


    @Override
    public Boolean visitFloatEle(FloatEleContext ctx) {
        stack.push(new FloatPrimitiveOprand(ctx.getText()));
        return true;
    }


    @Override
    public Boolean visitStringEle(StringEleContext ctx) {
        String str = ctx.STRING().getText();
        stack.push(new StringPrimitiveOprand(str.substring(1, str.length() - 1)));
        return true;
    }


    @Override
    public Boolean visitAggregationName(AggregationNameContext ctx) {
        AggregationNameContext aggregation = (AggregationNameContext) ctx;
        if (visitName(aggregation.columnName)) {
            String aggFun = aggregation.ID().getText();
            // 里面返回的oprand
            Oprand inOprand = (Oprand) stack.pop();
            // 聚合的Oprand
            Oprand aggregationOprand = (Oprand) FuncationManager.getFuncation(aggFun).call(inOprand);
            // 入栈
            stack.push(aggregationOprand);
            return true;
        }
        return false;
    }


    @Override
    public Boolean visitGranularityCluaster(GranularityCluasterContext ctx) {
        GranularityExprContext granExpr = ctx.granularityExpr();
        if (granExpr instanceof SimpleGranContext) {
            return visitSimpleGran((SimpleGranContext) granExpr);
        } else if (granExpr instanceof DurationGranContext) {
            return visitDurationGran((DurationGranContext) granExpr);
        } else if (granExpr instanceof PeriodGranContext) {
            return visitPeriodGran((PeriodGranContext) granExpr);
        }
        return false;
    }


    @Override
    public Boolean visitSimpleGran(SimpleGranContext ctx) {
        stack.push(new SimpleGranularity(ctx.simple.getText().toLowerCase()));
        return true;
    }


    @Override
    public Boolean visitDurationGran(DurationGranContext ctx) {
        long left = 0;
        if (ctx.left != null) {
            left = Long.valueOf(ctx.left.getText());
        }
        long right = Long.valueOf(ctx.right.getText());
        stack.push(new DurationGranularity(right, left));
        return true;
    }


    @Override
    public Boolean visitPeriodGran(PeriodGranContext ctx) {
        long left = 0;
        if (ctx.left != null) {
            left = Long.valueOf(ctx.left.getText());
        }
        String right = ctx.right.getText();
        String timeZone = ctx.timeZone.getText();
        stack.push(new PeriodGranularity(right, timeZone, left));
        return true;
    }

}
