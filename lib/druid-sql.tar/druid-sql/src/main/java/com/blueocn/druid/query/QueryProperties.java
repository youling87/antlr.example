package com.blueocn.druid.query;

import com.blueocn.druid.compiler.GroupByCompiler;
import com.blueocn.druid.compiler.TimeSeriesCompiler;
import com.blueocn.druid.compiler.TopNCompiler;

public interface QueryProperties {
    String             URL          = "url";
    String             CONTENT_TYPE = "content-type";

    TimeSeriesCompiler timeSeries   = new TimeSeriesCompiler();
    TopNCompiler       topn         = new TopNCompiler();
    GroupByCompiler    groupBy      = new GroupByCompiler();
}
