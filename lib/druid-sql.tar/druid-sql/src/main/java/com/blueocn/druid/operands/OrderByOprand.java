package com.blueocn.druid.operands;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.aggregators.IAggregator;

@Data
@EqualsAndHashCode
@AllArgsConstructor
public class OrderByOprand implements Oprand {
    private final Oprand  oprand;
    private final boolean desc;

    @Override
    public IAggregator getAggregator() {
        return null;
    }
}
