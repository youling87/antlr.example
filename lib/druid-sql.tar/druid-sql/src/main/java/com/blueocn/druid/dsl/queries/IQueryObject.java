package com.blueocn.druid.dsl.queries;

import com.blueocn.druid.dsl.EnumQueryType;


public interface IQueryObject {

    /**
     * query type, only topn, group by and timeseries supported.
     */
    EnumQueryType getQueryType();

    /**
     * druid data source name
     */
    String getDataSource();

}
