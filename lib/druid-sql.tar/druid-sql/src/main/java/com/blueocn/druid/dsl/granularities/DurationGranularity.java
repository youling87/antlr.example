package com.blueocn.druid.dsl.granularities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import org.apache.commons.lang3.time.DateFormatUtils;

import com.alibaba.fastjson.JSONAware;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class DurationGranularity implements Granularity, JSONAware {
    private final String type = "duration";
    /**
     * milliseconds
     */
    private final long   duration;
    private final long   origin;

    @Override
    public String toJSONString() {
        StringBuilder sb = new StringBuilder("{ \"type\":\"duration\",");
        sb.append("\"duration\":");
        sb.append(duration);
        if (origin > 0) {
            sb.append(",");
            sb.append("\"origin\":");
            sb.append("\"");
            sb.append(DateFormatUtils.formatUTC(origin, DateFormatUtils.ISO_DATETIME_FORMAT.getPattern()));
            sb.append("\"");
        }
        sb.append("}");
        return sb.toString();
    }
}
