package com.blueocn.druid.operands.math;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.aggregators.MathAggregator;
import com.blueocn.druid.operands.NameOprand;
import com.blueocn.druid.operands.Oprand;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class MinOprand implements Oprand {

    private final String     type;
    private final NameOprand name;

    @Override
    public IAggregator getAggregator() {
        return new MathAggregator(type, null, name.getColumn());
    }

}
