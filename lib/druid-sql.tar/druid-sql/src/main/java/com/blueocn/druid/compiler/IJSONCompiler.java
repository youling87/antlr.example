package com.blueocn.druid.compiler;

import com.blueocn.druid.parser.Query;

/**
 * interface for compiling query object to JSON
 * 
 * @author zhxiaog
 *
 */
public interface IJSONCompiler {
    String compile(Query query);

    boolean canCompile(Query query);
}
