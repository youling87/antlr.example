package com.blueocn.druid.operands;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.aggregators.IAggregator;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class AliasOprand implements Oprand {
    private final Oprand oprand;
    private final String alias;

    /**
     * TODO: remove set
     */
    @Override
    public IAggregator getAggregator() {
        IAggregator agg = oprand.getAggregator();
        agg.setName(alias);
        return agg;
    }

}
