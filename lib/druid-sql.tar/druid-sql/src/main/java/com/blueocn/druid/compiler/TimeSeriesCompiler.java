package com.blueocn.druid.compiler;

import org.apache.commons.collections.CollectionUtils;

import com.blueocn.druid.dsl.queries.IQueryObject;
import com.blueocn.druid.dsl.queries.TimeSeriesQuery;
import com.blueocn.druid.parser.Query;

public class TimeSeriesCompiler extends AbstractCompiler {

    @Override
    public boolean canCompile(Query query) {
        return CollectionUtils.isEmpty(query.getOrderBy()) && CollectionUtils.isEmpty(query.getGroupBys()) && query.getLimit() == null && query.getGranularity() != null;
    }

    @Override
    protected IQueryObject compile(CompilerContext context) {
        TimeSeriesQuery queryObject =
                TimeSeriesQuery.builder().dataSource(context.getDataSource()).filter(context.getFilter()).aggregations(context.getAggregators().keySet())
                        .postAggregations(context.getPostAggregators().keySet()).granularity(context.getGranularity()).intervals(context.getInterval()).build();
        return queryObject;
    }

}
