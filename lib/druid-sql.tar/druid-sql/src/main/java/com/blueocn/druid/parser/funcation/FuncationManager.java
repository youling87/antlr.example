package com.blueocn.druid.parser.funcation;

import java.lang.reflect.Constructor;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.blueocn.druid.operands.CountOprand;
import com.blueocn.druid.operands.NameOprand;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.operands.math.MaxOprand;
import com.blueocn.druid.operands.math.MinOprand;
import com.blueocn.druid.operands.math.SumOprand;


public class FuncationManager {
    private static final Map<String, Funcation> funs = new ConcurrentHashMap<String, Funcation>();


    static {
        funs.put("longsum", new CommonFuncation(SumOprand.class, "longSum"));
        funs.put("doublesum", new CommonFuncation(SumOprand.class, "doubleSum"));
        funs.put("longmax", new CommonFuncation(MaxOprand.class, "longMax"));
        funs.put("doublemin", new CommonFuncation(MaxOprand.class, "doubleMax"));
        funs.put("longmin", new CommonFuncation(MinOprand.class, "longMin"));
        funs.put("doublemin", new CommonFuncation(MinOprand.class, "doubleMin"));
        //funs.put("count", new CommonFuncation(CountOprand.class, "count"));
        funs.put("count",new CountFuncation());

    }


    public static Funcation getFuncation(String funcationname) {
        if (!funs.containsKey(funcationname.toLowerCase())) {
            throw new RuntimeException("parse sql error:not found " + funcationname + " funcation");
        }
        return funs.get(funcationname.toLowerCase());
    }
}


class CommonFuncation implements Funcation {
    private Constructor<? extends Oprand> constructor;
    private String                        type;

    public CommonFuncation(Class<? extends Oprand> oprandClazz, String type) {
        try {
            constructor = oprandClazz.getConstructor(String.class, NameOprand.class);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        this.type = type;
    }

    @Override
    public Object call(Object... args) {
        try {
            return constructor.newInstance(type, (NameOprand) args[0]);
        } catch (Exception e) {

        }
        throw new RuntimeException("parser sql aggregators error");
    }

}


class CountFuncation implements Funcation {

    @Override
    public Object call(Object... args) {
        return new CountOprand("count", (Oprand) args[0]);
    }

}
