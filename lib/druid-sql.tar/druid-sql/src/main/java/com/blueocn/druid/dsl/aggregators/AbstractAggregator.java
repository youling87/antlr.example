package com.blueocn.druid.dsl.aggregators;


public abstract class AbstractAggregator implements IAggregator {

    public boolean isPostAggregator() {
        return false;
    }
}
