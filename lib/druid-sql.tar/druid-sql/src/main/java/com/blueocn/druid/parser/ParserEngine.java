package com.blueocn.druid.parser;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.apache.commons.lang3.StringUtils;

import com.blueocn.druid.parser.DruidQuery.ProgContext;
import com.blueocn.druid.parser.impl.DruidQueryVisitor;
import com.blueocn.druid.parser.impl.SqlAntlrErrorStrategy;
import com.blueocn.druid.parser.impl.SyntaxErrorListener;

public class ParserEngine {

    public static Query parse(String sql) {
        if (StringUtils.isBlank(sql))
            throw new RuntimeException();

        SyntaxErrorListener listener = new SyntaxErrorListener();

        ANTLRInputStream input = new ANTLRInputStream(sql);

        DruidLexer lexer = new DruidLexer(input);
        lexer.removeErrorListeners();
        // 分词的错误处理
        lexer.addErrorListener(listener);

        CommonTokenStream token = new CommonTokenStream(lexer);

        DruidQuery query = new DruidQuery(token);
        // 解析的错误处理
        query.setErrorHandler(new SqlAntlrErrorStrategy());


        ProgContext progTree = query.prog();
        DruidQueryVisitor visitor = new DruidQueryVisitor();
        if (visitor.visit(progTree)) {
            return visitor.getQuery();
        }
        throw new RuntimeException("SQL parser error!!!");
    }
}
