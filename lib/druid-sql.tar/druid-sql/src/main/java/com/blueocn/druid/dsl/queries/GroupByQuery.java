package com.blueocn.druid.dsl.queries;

import java.util.Collection;
import java.util.List;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NonNull;

import com.blueocn.druid.dsl.DefaultLimitSpec;
import com.blueocn.druid.dsl.EnumQueryType;
import com.blueocn.druid.dsl.Interval;
import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.filters.Filter;
import com.blueocn.druid.dsl.granularities.Granularity;

@Data
@EqualsAndHashCode
@Builder
public class GroupByQuery implements IQueryObject {
    private final EnumQueryType           queryType = EnumQueryType.groupBy;
    @NonNull
    private final String                  dataSource;
    @NonNull
    private final List<String>            dimensions;
    @NonNull
    private final DefaultLimitSpec        limitSpec;
    @NonNull
    private final Filter                  filter;
    @NonNull
    private final Granularity             granularity;
    @NonNull
    private final Collection<IAggregator> aggregations;
    private final Collection<IAggregator> postAggregations;
    @NonNull
    private Interval                      intervals;

    // TODO: having

}
