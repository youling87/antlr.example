package com.blueocn.druid.dsl;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import org.apache.commons.lang3.time.DateFormatUtils;

import com.alibaba.fastjson.JSONAware;

@Data
@Builder
@EqualsAndHashCode
public class Interval implements JSONAware {
    private final long startTime;
    private final long endTime;

    @Override
    public String toJSONString() {
        return String.format("\"%s/%s\"", DateFormatUtils.formatUTC(startTime, DateFormatUtils.ISO_DATETIME_FORMAT.getPattern()),
                DateFormatUtils.formatUTC(endTime, DateFormatUtils.ISO_DATETIME_FORMAT.getPattern()));
    }
}
