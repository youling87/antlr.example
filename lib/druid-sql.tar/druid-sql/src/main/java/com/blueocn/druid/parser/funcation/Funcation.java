package com.blueocn.druid.parser.funcation;

public interface Funcation {
    Object call(Object... args);
}
