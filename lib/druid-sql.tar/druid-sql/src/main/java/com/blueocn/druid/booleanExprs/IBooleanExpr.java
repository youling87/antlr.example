package com.blueocn.druid.booleanExprs;

import com.blueocn.druid.dsl.filters.Filter;

public interface IBooleanExpr {
    Filter getFilter();
}
