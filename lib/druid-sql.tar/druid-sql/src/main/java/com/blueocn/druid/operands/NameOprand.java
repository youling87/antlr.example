package com.blueocn.druid.operands;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.aggregators.IAggregator;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class NameOprand implements Oprand {

    private final String table;
    private final String column;

    @Override
    public IAggregator getAggregator() {
        return null;
    }
}
