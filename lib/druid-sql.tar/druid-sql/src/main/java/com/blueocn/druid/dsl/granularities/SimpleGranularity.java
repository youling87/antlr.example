package com.blueocn.druid.dsl.granularities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.alibaba.fastjson.JSONAware;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class SimpleGranularity implements Granularity, JSONAware {
    private final String name;

    @Override
    public String toJSONString() {
        return "\"" + name + "\"";
    }

}
