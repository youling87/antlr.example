package com.blueocn.druid.operands.binary;

import com.blueocn.druid.operands.Oprand;

/**
 * / division always returns 0 if dividing by0, regardless of the numerator.<br>
 * {@link http://druid.io/docs/0.8.0/querying/post-aggregations.html}
 * 
 * @author zhxiaog
 *
 */
public class DividOprand extends BinaryOprand {

    public DividOprand(Oprand left, Oprand right) {
        super(left, right, "/");
    }
}
