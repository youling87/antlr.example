package com.blueocn.druid.operands.binary;

import com.blueocn.druid.operands.Oprand;

public class MultiplyOprand extends BinaryOprand {

    public MultiplyOprand(Oprand left, Oprand right) {
        super(left, right, "*");
    }

}
