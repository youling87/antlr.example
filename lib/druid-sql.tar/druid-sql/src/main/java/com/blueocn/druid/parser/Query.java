package com.blueocn.druid.parser;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import org.apache.commons.lang3.tuple.Pair;

import com.blueocn.druid.booleanExprs.IBooleanExpr;
import com.blueocn.druid.dsl.granularities.Granularity;
import com.blueocn.druid.operands.LimitOprand;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.operands.OrderByOprand;

@Data
@AllArgsConstructor
@Builder
@EqualsAndHashCode
public class Query {
    private final String              table;
    private final List<Oprand>        columns;
    private final IBooleanExpr        whereClause;
    private final List<OrderByOprand> orderBy;
    private final List<Oprand>        groupBys;
    private final Pair<Long, Long>    timestamps;
    private final LimitOprand         limit;
    private final Granularity         granularity;
}
