package com.blueocn.druid;

import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.druid.parser.ParserEngine;
import com.blueocn.druid.parser.Query;
import com.blueocn.druid.query.QueryManager;
import com.blueocn.druid.query.QueryProperties;

/**
 * druid查询封装,可以注入到spring中
 * 
 * @author <a href="mailto:zhangjianyf@oneapm.com">zhangjianyf@oneapm.com</a>
 *
 */
public class SqlRunner {
    private QueryManager queryManager;

    /**
     * 初始化一个Sql执行容器
     * 
     * @param properties <see>QueryProperties</see>
     */
    public SqlRunner(Properties properties) {
        queryManager = new QueryManager(properties);
    }


    public  <T> List<T> queryList(String sql, Class<T> clazz) {
        JSONArray array = (JSONArray) query(sql);
        return JSONArray.parseArray(JSON.toJSONString(array), clazz);
    }

    public  <T> T queryObject(String sql, Class<T> clazz) {
        JSONObject object = (JSONObject) query(sql);
        return JSONObject.parseObject(JSON.toJSONString(object), clazz);
    }

    public Object queryObject(String sql) {
        return query(sql);
    }

    private  Object query(String sql) {
        Query query = ParserEngine.parse(sql);
        if (query != null) {
            String json = null;
            if (QueryProperties.timeSeries.canCompile(query)) {
                json = QueryProperties.timeSeries.compile(query);
            } else if (QueryProperties.topn.canCompile(query)) {
                json = QueryProperties.topn.compile(query);
            } else if (QueryProperties.groupBy.canCompile(query)) {
                json = QueryProperties.groupBy.compile(query);
            }
            if (StringUtils.isNotBlank(json)) {
                return queryManager.query(JSON.parseObject(json));
            }
        }
        throw new RuntimeException("sql query error!!");
    }

    public void close() throws Exception {
        this.queryManager.close();
    }
}
