package com.blueocn.druid.booleanExprs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.filters.Filter;
import com.blueocn.druid.dsl.filters.SelectorFilter;
import com.blueocn.druid.operands.NameOprand;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.operands.primitive.PrimitiveOprand;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class BooleanExprEq implements IBooleanExpr {
    private final Oprand left;
    private final Oprand right;

    @Override
    public Filter getFilter() {
        NameOprand op = (NameOprand) (NameOprand.class.isInstance(left) ? left : right);
        PrimitiveOprand pop = (PrimitiveOprand) (PrimitiveOprand.class.isInstance(left) ? left : right);
        return new SelectorFilter(op.getColumn(), pop.getValue());

    }
}
