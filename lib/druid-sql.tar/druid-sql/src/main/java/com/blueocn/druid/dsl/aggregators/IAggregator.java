package com.blueocn.druid.dsl.aggregators;

import com.alibaba.fastjson.annotation.JSONField;


public interface IAggregator {
    String getType();

    String getName();

    // TODO: remove this
    void setName(String value);

    @JSONField(deserialize = false, serialize = false)
    boolean isPostAggregator();
}
