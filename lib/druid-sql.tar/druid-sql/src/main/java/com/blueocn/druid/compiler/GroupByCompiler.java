package com.blueocn.druid.compiler;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.blueocn.druid.dsl.DefaultLimitSpec;
import com.blueocn.druid.dsl.queries.GroupByQuery;
import com.blueocn.druid.dsl.queries.IQueryObject;
import com.blueocn.druid.parser.Query;

public class GroupByCompiler extends AbstractCompiler {

    @Override
    public boolean canCompile(Query query) {
        return query.getLimit() != null && query.getLimit().getMaxSize() > 0 && CollectionUtils.isNotEmpty(query.getGroupBys()) && CollectionUtils.isNotEmpty(query.getOrderBy())
                && (query.getOrderBy().size() >= 1 || query.getGroupBys().size() > 1);
    }

    @Override
    protected void beforeCompile(CompilerContext context) {
        // get order by
        DefaultLimitSpec limit = CompilerUtils.getLimitSpec4groupBy(context);
        context.getSession().put("limit", limit);
    }

    @Override
    protected IQueryObject compile(final CompilerContext context) {
        // get group by dimension
        List<String> dimensions = CompilerUtils.getGroupBys(context);
        DefaultLimitSpec limitSpec = CompilerUtils.getLimitSpec4groupBy(context);
        GroupByQuery queryObject =
                GroupByQuery.builder().dataSource(context.getDataSource()).dimensions(dimensions).limitSpec(limitSpec).filter(context.getFilter())
                        .aggregations(context.getAggregators().keySet()).postAggregations(context.getPostAggregators().keySet()).granularity(context.getGranularity())
                        .intervals(context.getInterval()).build();
        return queryObject;
    }

}
