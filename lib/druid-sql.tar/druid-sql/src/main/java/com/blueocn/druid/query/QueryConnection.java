package com.blueocn.druid.query;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;

public class QueryConnection implements FutureCallback<HttpResponse> {

    private CloseableHttpAsyncClient asyncClient;
    private Properties               properties;

    private Exception                ex;
    private CountDownLatch           latch = new CountDownLatch(1);

    public QueryConnection(CloseableHttpAsyncClient client, Properties pro) {
        this.asyncClient = client;
        this.properties = pro;
    }

    public <T> Object query(JSONObject object) {
        try {
            RequestBuilder builder =
                    RequestBuilder.post().setHeader("content-type", properties.getProperty(QueryProperties.CONTENT_TYPE, "application/json"))
                            .setUri(properties.getProperty(QueryProperties.URL)).setEntity(new StringEntity(JSON.toJSONString(object)));

            Future<HttpResponse> future = asyncClient.execute(builder.build(), this);
            latch.await();
            if (ex != null) {
                throw new RuntimeException(ex);
            } else {
                HttpResponse response = future.get();
                if (response != null) {
                    // SUCCESS
                    if (response.getStatusLine().getStatusCode() == 200) {
                        String json = EntityUtils.toString(response.getEntity());
                        System.out.println(json);
                        if (StringUtils.isNotBlank(json)) {
                            json = json.trim();
                            try {
                                if (json.startsWith("{")) {
                                    return JSONObject.parseObject(json);
                                } else if (json.startsWith("[")) {
                                    return JSONArray.parseArray(json);
                                }
                            } catch (JSONException e) {
                                print(e.getLocalizedMessage());
                            }
                        }
                        throw new RuntimeException("druid返回结果错误:" + json);
                    }
                    throw new RuntimeException("druid查询错误,返回状态码:" + response.getStatusLine().getStatusCode() + "\t response body:" + EntityUtils.toString(response.getEntity()));
                } else {
                    print("取消查询");
                    return null;
                }
            }
        } catch (UnsupportedEncodingException e1) {
            throw new RuntimeException("查询参数错误:" + JSON.toJSONString(object, true));
        } catch (InterruptedException e) {
            throw new RuntimeException("druid查询连接超时", e);
        } catch (ParseException e) {
            throw new RuntimeException("查询参数错误:" + JSON.toJSONString(object, true));
        } catch (IOException e) {
            throw new RuntimeException("http请求时发生错误", e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    public void close() throws Exception {
        asyncClient.close();
    }

    private void print(String str) {
        // 决定打什么流, logger? syso?
    }


    @Override
    public void completed(HttpResponse result) {
        latch.countDown();
    }

    @Override
    public void failed(Exception ex) {
        this.ex = ex;
        latch.countDown();
    }

    @Override
    public void cancelled() {
        latch.countDown();
    }

}
