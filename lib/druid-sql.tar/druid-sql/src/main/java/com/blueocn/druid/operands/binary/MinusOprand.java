package com.blueocn.druid.operands.binary;

import com.blueocn.druid.operands.Oprand;

public class MinusOprand extends BinaryOprand {

    public MinusOprand(Oprand left, Oprand right) {
        super(left, right, "-");
    }

}
