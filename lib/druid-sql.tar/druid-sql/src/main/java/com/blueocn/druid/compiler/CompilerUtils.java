package com.blueocn.druid.compiler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import com.blueocn.druid.dsl.DefaultLimitSpec;
import com.blueocn.druid.dsl.EnumOrderByDirection;
import com.blueocn.druid.dsl.OrderByColumnSpec;
import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.postAggregators.IPostAggregator;
import com.blueocn.druid.operands.LimitOprand;
import com.blueocn.druid.operands.NameOprand;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.operands.OrderByOprand;

public class CompilerUtils {
    /**
     * 
     * @param query
     * @return
     */
    public static List<String> getGroupBys(CompilerContext context) {
        List<String> result = new ArrayList<String>();
        for (Oprand op : context.getQuery().getGroupBys()) {
            if (NameOprand.class.isInstance(op)) {
                NameOprand nop = (NameOprand) op;
                result.add(nop.getColumn());
            }
        }
        return result;
    }

    public static DefaultLimitSpec getLimitSpec4groupBy(CompilerContext context) {
        LimitOprand limit = context.getQuery().getLimit();

        List<OrderByColumnSpec> orderByColumns = new ArrayList<OrderByColumnSpec>();
        List<Pair<String, Boolean>> orderBys = getOrderBys(context);
        for (Pair<String, Boolean> orderBy : orderBys) {
            orderByColumns.add(new OrderByColumnSpec(orderBy.getLeft(), EnumOrderByDirection.get(orderBy.getRight())));
        }
        return DefaultLimitSpec.builder().limit(limit.getMaxSize()).columns(orderByColumns).build();
    }

    private static List<Pair<String, Boolean>> getOrderBys(CompilerContext context) {
        List<Pair<String, Boolean>> orderBys = new ArrayList<Pair<String, Boolean>>();
        for (OrderByOprand op : context.getQuery().getOrderBy()) {
            Pair<String, Boolean> orderBy = Pair.of(getOrderBy(op, context.getAggregators(), context.getPostAggregators()), op.isDesc());
            if (StringUtils.isNotBlank(orderBy.getLeft())) {
                orderBys.add(orderBy);
            }
        }
        return orderBys;
    }

    private static String getOrderBy(final OrderByOprand orderByOpr, final Map<IAggregator, String> aggsMap, final Map<IAggregator, String> postAggsMap) {
        String result = null;
        Oprand oprand = orderByOpr.getOprand();
        if (NameOprand.class.isInstance(oprand)) {
            result = ((NameOprand) oprand).getColumn();
        } else {
            IAggregator agg = oprand.getAggregator();
            result = aggsMap.getOrDefault(agg, postAggsMap.get(agg));
            if (StringUtils.isBlank(result)) {
                result = agg.toString();
                if (agg.isPostAggregator()) {
                    String previous = postAggsMap.putIfAbsent(agg, agg.toString());
                    if (previous == null) {
                        agg.setName(agg.toString());
                        // we have to parse postAggregation see if there is any aggregation need to
                        // add to aggregations map
                        for (IAggregator a : ((IPostAggregator) agg).getAggregators()) {
                            if (StringUtils.isNotBlank(a.getName())) {
                                aggsMap.put(a, a.getName());
                            } else {
                                aggsMap.putIfAbsent(a, a.toString());
                            }
                        }
                    }
                } else {
                    aggsMap.putIfAbsent(agg, agg.toString());
                }
            }
        }
        return result;
    }

    /**
     * get order by metric name<br>
     * if order by is a nameOprand, in which case can be treated as a field accessor, return
     * nameOprand's column name<br>
     * if order by is not a nameOprand, we need to parse the aggregations and add them to the
     * aggregations map and post aggregation map.
     * 
     * @param orderByOprand
     * @param aggsMap
     * @param postAggsMap
     * @return
     */
    public static String getOrderBy4TopN(CompilerContext context) {
        return getOrderBy(context.getQuery().getOrderBy().get(0), context.getAggregators(), context.getPostAggregators());
    }



}
