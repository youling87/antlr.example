package com.blueocn.druid.query;

import java.util.Properties;

import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;

public class QueryConnectionPool {
    
    public static QueryConnection getConnection(Properties properties) {
        CloseableHttpAsyncClient client = HttpAsyncClients.createDefault();
        client.start();
        return new QueryConnection(client, properties);
    }
}
