package com.blueocn.druid.compiler;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import com.blueocn.druid.dsl.queries.IQueryObject;
import com.blueocn.druid.dsl.queries.TopNQuery;
import com.blueocn.druid.parser.Query;

public class TopNCompiler extends AbstractCompiler {
    @Override
    public boolean canCompile(Query query) {
        return query.getLimit() != null && query.getLimit().getOffeset() >= 0 && query.getLimit().getResultCount() > 0 && CollectionUtils.isNotEmpty(query.getGroupBys())
                && query.getGroupBys().size() == 1 && CollectionUtils.isNotEmpty(query.getOrderBy()) && query.getOrderBy().size() == 1;
    }

    @Override
    protected void beforeCompile(CompilerContext context) {
        // get order by
        final String orderByMetric = CompilerUtils.getOrderBy4TopN(context);
        final boolean desc = context.getQuery().getOrderBy().get(0).isDesc();
        context.getSession().put("metric", orderByMetric);
        context.getSession().put("isOrderByDesc", desc);
    }

    @Override
    protected IQueryObject compile(CompilerContext context) {
        // get group by dimension
        List<String> groupBys = CompilerUtils.getGroupBys(context);
        final String groupDim = groupBys.get(0);
        final int limit = context.getQuery().getLimit().getMaxSize();
        String metric = context.getSession().get("metric").toString();
        TopNQuery queryObject =
                TopNQuery.builder().dataSource(context.getDataSource()).dimension(groupDim).threshold(limit).metric(metric).filter(context.getFilter())
                        .aggregations(context.getAggregators().keySet()).postAggregations(context.getPostAggregators().keySet()).granularity(context.getGranularity())
                        .intervals(context.getInterval()).build();
        return queryObject;
    }
}
