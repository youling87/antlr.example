package com.blueocn.druid.compiler;

import java.util.HashMap;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

import com.blueocn.druid.dsl.Interval;
import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.filters.Filter;
import com.blueocn.druid.dsl.granularities.Granularity;
import com.blueocn.druid.parser.Query;

@Data
@Builder
public class CompilerContext {
    private Query                     query;
    private String                    dataSource;
    private Filter                    filter;
    private Granularity               granularity;
    private Map<IAggregator, String>  aggregators;
    private Map<IAggregator, String>  postAggregators;
    private Interval                  interval;

    private final Map<String, Object> session = new HashMap<String, Object>();
}
