package com.blueocn.druid.operands;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.aggregators.CountAggregator;
import com.blueocn.druid.dsl.aggregators.IAggregator;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class CountOprand implements Oprand {

    private final String type;
    private final Oprand name;

    @Override
    public IAggregator getAggregator() {
        return new CountAggregator();
    }

}
