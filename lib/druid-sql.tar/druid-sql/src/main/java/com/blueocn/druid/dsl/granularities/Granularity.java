package com.blueocn.druid.dsl.granularities;

public interface Granularity {

}
