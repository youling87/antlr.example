package com.blueocn.druid.dsl.postAggregators;

import java.util.Set;

import com.alibaba.fastjson.annotation.JSONField;
import com.blueocn.druid.dsl.aggregators.IAggregator;

public interface IPostAggregator extends IAggregator {


    /**
     * get aggregations used by Druid.io; not postAggregations
     * 
     * @return
     */
    @JSONField(deserialize = false, serialize = false)
    Set<IAggregator> getAggregators();
}
