package com.blueocn.druid.compiler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;
import com.blueocn.druid.dsl.Interval;
import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.filters.Filter;
import com.blueocn.druid.dsl.granularities.Granularity;
import com.blueocn.druid.dsl.postAggregators.ArithmeticPostAggregator;
import com.blueocn.druid.dsl.postAggregators.FieldAccessPostAggregator;
import com.blueocn.druid.dsl.postAggregators.IPostAggregator;
import com.blueocn.druid.dsl.queries.IQueryObject;
import com.blueocn.druid.operands.Oprand;
import com.blueocn.druid.parser.Query;

public abstract class AbstractCompiler implements IJSONCompiler {

    @Override
    public final String compile(final Query query) {

        CompilerContext context = buildContext(query);

        beforeCompile(context);

        compileAlias(context);

        final IQueryObject queryObject = compile(context);

        afterCompile(context, queryObject);

        return JSON.toJSONString(queryObject);
    }

    /**
     * override this method if you want to change compiler context before it actually gets compiled
     * 
     * @param context
     */
    protected void beforeCompile(final CompilerContext context) {}

    /**
     * you must override this method to build a query object out of compiler context
     * 
     * @param context
     * @return
     */
    protected abstract IQueryObject compile(final CompilerContext context);

    /**
     * this is the last chance where you can change the final query object or get some compiler
     * context information
     * 
     * @param context
     * @param queryObject
     */
    protected void afterCompile(final CompilerContext context, final IQueryObject queryObject) {}

    /**
     * build a compiler context from query instance
     * 
     * @param query
     * @return
     */
    private CompilerContext buildContext(Query query) {
        // parse where clause
        Filter filter = query.getWhereClause().getFilter();

        // parse selected columns
        List<Oprand> oprands = query.getColumns();
        Map<IAggregator, String> postAggregators = new HashMap<IAggregator, String>();
        Map<IAggregator, String> aggregators = new HashMap<IAggregator, String>();
        Collection<IAggregator> aggregatorsList = null;
        for (Oprand op : oprands) {
            IAggregator agg = op.getAggregator();
            if (!agg.isPostAggregator()) {
                aggregatorsList = Arrays.asList(agg);
            } else {
                if (StringUtils.isNotBlank(agg.getName())) {
                    postAggregators.put(agg, agg.getName());
                } else {
                    postAggregators.putIfAbsent(agg, agg.toString());
                }
                aggregatorsList = ((IPostAggregator) agg).getAggregators();
            }
            if (CollectionUtils.isNotEmpty(aggregatorsList)) {
                for (IAggregator a : aggregatorsList) {
                    if (StringUtils.isNotBlank(a.getName())) {
                        aggregators.put(a, a.getName());
                    } else {
                        aggregators.putIfAbsent(a, a.toString());
                    }
                }
            }
        }


        // get interval and granularity
        Interval interval = Interval.builder().startTime(query.getTimestamps().getLeft()).endTime(query.getTimestamps().getRight()).build();
        Granularity granularity = query.getGranularity();

        // build compiler context
        CompilerContext context =
                CompilerContext.builder().query(query).dataSource(query.getTable()).aggregators(aggregators).postAggregators(postAggregators).interval(interval)
                        .granularity(granularity).filter(filter).build();
        return context;
    }

    /**
     * this code does: <br>
     * 1. replace aggregations in postAggregations with fieldAccessPostAggregation <br>
     * 2. set aggregation alias if not set before
     * 
     * @param context
     */
    private void compileAlias(CompilerContext context) {
        for (IAggregator agg : context.getPostAggregators().keySet()) {
            if (agg.isPostAggregator()) {
                replaceAggregatorWithFieldAccess((IPostAggregator) agg, context.getAggregators());
            }
        }

        for (Entry<IAggregator, String> entry : context.getAggregators().entrySet()) {
            entry.getKey().setName(entry.getValue());
        }
    }

    /**
     * replace aggregations in postAggregations with fieldAccessPostAggregation <br>
     * 
     * @param postAgg
     * @param aggMap
     */
    private void replaceAggregatorWithFieldAccess(IPostAggregator postAgg, final Map<IAggregator, String> aggMap) {
        if (ArithmeticPostAggregator.class.isInstance(postAgg)) {
            ArithmeticPostAggregator aagg = (ArithmeticPostAggregator) postAgg;
            Collection<IPostAggregator> postAggs = new ArrayList<IPostAggregator>();
            for (IAggregator agg : aagg.getSubAggregators()) {
                if (agg.isPostAggregator()) {
                    replaceAggregatorWithFieldAccess((IPostAggregator) agg, aggMap);
                    postAggs.add((IPostAggregator) agg);
                } else {
                    postAggs.add(new FieldAccessPostAggregator(aggMap.get(agg)));
                }
            }
            aagg.getFields().addAll(postAggs);
        }
    }
}
