package com.blueocn.druid.operands.primitive;

import com.blueocn.druid.operands.Oprand;

public interface PrimitiveOprand extends Oprand {
    String getValue();

}
