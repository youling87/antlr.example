package com.blueocn.druid.dsl.granularities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import com.alibaba.fastjson.JSONAware;

/**
 * http://druid.io/docs/0.8.0/querying/granularities.html
 * 
 * @author zhxiaog
 *
 */
@Data
@AllArgsConstructor
@EqualsAndHashCode
public class PeriodGranularity implements Granularity, JSONAware {
    private final String type = "period";
    private final String period;
    private final String timeZone;
    private final long   origin;

    @Override
    public String toJSONString() {
        StringBuilder sb = new StringBuilder("{ \"type\":\"period\",");
        sb.append("\"period\":");
        sb.append("\"");
        sb.append(period);
        sb.append("\"");
        if (origin > 0) {
            sb.append(",");
            sb.append("\"origin\":");
            sb.append("\"");
            sb.append(DateFormatUtils.formatUTC(origin, DateFormatUtils.ISO_DATETIME_FORMAT.getPattern()));
            sb.append("\"");
        }
        if (StringUtils.isNotBlank(timeZone)) {
            sb.append(",");
            sb.append("\"timeZone\":");
            sb.append("\"");
            sb.append(timeZone);
            sb.append("\"");
        }
        sb.append("}");
        return sb.toString();
    }


}
