package com.blueocn.druid.dsl.queries;

import java.util.Collection;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NonNull;

import com.blueocn.druid.dsl.EnumQueryType;
import com.blueocn.druid.dsl.Interval;
import com.blueocn.druid.dsl.aggregators.IAggregator;
import com.blueocn.druid.dsl.filters.Filter;
import com.blueocn.druid.dsl.granularities.Granularity;

@Data
@Builder
@EqualsAndHashCode
public class TopNQuery implements IQueryObject {
    private final EnumQueryType           queryType = EnumQueryType.topN;
    @NonNull
    private final String                  dataSource;
    @NonNull
    private final String                  dimension;
    private final int                     threshold;
    @NonNull
    private final String                  metric;
    @NonNull
    private final Filter                  filter;
    @NonNull
    private final Granularity             granularity;
    @NonNull
    private final Collection<IAggregator> aggregations;
    private final Collection<IAggregator> postAggregations;
    @NonNull
    private Interval                      intervals;
}
