package com.blueocn.druid.booleanExprs;

import java.util.Arrays;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import com.blueocn.druid.dsl.filters.AndOrFilter;
import com.blueocn.druid.dsl.filters.Filter;

@Data
@AllArgsConstructor
@EqualsAndHashCode
public class BooleanExprOr implements IBooleanExpr {
    private final IBooleanExpr left;
    private final IBooleanExpr right;

    @Override
    public Filter getFilter() {
        return new AndOrFilter("or", Arrays.asList(left.getFilter(), right.getFilter()));
    }
}
