package com.blueocn.druid.dsl.postAggregators;


public abstract class AbstractPostAggregator implements IPostAggregator {

    public boolean isPostAggregator() {
        return true;
    }

}
