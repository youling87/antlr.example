package com.blueocn.druid.query;

import java.util.Properties;

import com.alibaba.fastjson.JSONObject;

public class QueryManager {
    private QueryConnection queryConnection;

    public QueryManager(Properties pro) {
        this.queryConnection = QueryConnectionPool.getConnection(pro);
    }

    public Object query(JSONObject jsonObject) {
        if (jsonObject == null) {
            throw new RuntimeException();
        }
        return this.queryConnection.query(jsonObject);
    }

    public void close() throws Exception {
        this.queryConnection.close();
    }

}
