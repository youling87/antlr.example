package com.blueocn.druid.dsl.aggregators;

public enum EnumBinaryAggregator {
    longSum, longMin, longMax, doubleSum, doubleMin, doubleMax
}
