package com.blueocn.tps.jdbc.driver.druid;

import java.lang.reflect.Field;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.alibaba.fastjson.JSONArray;
import com.blueocn.druid.SqlRunner;
import com.blueocn.tps.jdbc.misc.Properties;

@RunWith(MockitoJUnitRunner.class)
public class DruidConnectionTest {

    @InjectMocks
    private DruidConnection connection;

    @Mock
    private SqlRunner       sqlRunner;

    @Mock
    private Properties      properties;


    @Before
    public void setUp() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
        Mockito.when(sqlRunner.queryObject(Mockito.anyString())).thenAnswer(new Answer<Object>() {

            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                // http://druid.io/docs/0.8.0/querying/timeseriesquery.html
                String json =
                        "[{\"timestamp\":\"2012-01-01T00:00:00.000Z\",\"result\":{\"sample_name1\":\"sample_name1val\",\"sample_name2\":\"sample_name2val\",\"sample_divide\":\"sample_divideval\"}},{\"timestamp\":\"2012-01-02T00:00:00.000Z\",\"result\":{\"sample_name1\":\"sample_name1val\",\"sample_name2\":\"sample_name2val\",\"sample_divide\":\"sample_divideval\"}}]";
                return JSONArray.parse(json);
            }
        });
        Field field = connection.getClass().getDeclaredField("sqlRunner");
        field.setAccessible(true);
        field.set(connection, sqlRunner);
    }

    @Test
    public void prepareStatementTest() throws SQLException, ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH");
        PreparedStatement preparedStatement = connection.prepareStatement("select aaa from bbb");
        preparedStatement.execute();
        ResultSet resultSet = preparedStatement.getResultSet();

        Assert.assertTrue(resultSet.next());


        Assert.assertEquals(resultSet.getDate("timestamp"), new Date(format.parse("2012-01-01 08").getTime()));
        Assert.assertEquals(resultSet.getString("sample_name1"), "sample_name1val");
        Assert.assertEquals(resultSet.getString("sample_name2"), "sample_name2val");
        Assert.assertEquals(resultSet.getString("sample_divide"), "sample_divideval");

        Assert.assertTrue(resultSet.next());
        Assert.assertEquals(resultSet.getDate("timestamp"), new Date(format.parse("2012-01-02 08").getTime()));
        Assert.assertEquals(resultSet.getString("sample_name1"), "sample_name1val");
        Assert.assertEquals(resultSet.getString("sample_name2"), "sample_name2val");
        Assert.assertEquals(resultSet.getString("sample_divide"), "sample_divideval");

    }

    @Test
    public void resultSetMetaDataTest() throws Exception {
        PreparedStatement preparedStatement = connection.prepareStatement("select aaa from bbb");
        preparedStatement.execute();
        ResultSet resultSet = preparedStatement.getResultSet();
        Assert.assertNotNull(resultSet);
        ResultSetMetaData metaData=resultSet.getMetaData();
        Assert.assertNotNull(metaData);
        
        Assert.assertEquals(metaData.getColumnCount(), 4);

        
        
    }


}
