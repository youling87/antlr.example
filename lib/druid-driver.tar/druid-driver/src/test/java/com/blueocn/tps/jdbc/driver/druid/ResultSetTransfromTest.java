package com.blueocn.tps.jdbc.driver.druid;

import java.text.ParseException;

import junit.framework.Assert;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.junit.Test;

public class ResultSetTransfromTest {

    @Test
    public void testParser() throws ParseException {
        String dateStr = "2015-09-14T14:15:00.000Z";
        java.util.Date d = DateFormatUtils.ISO_DATETIME_FORMAT.parse(dateStr);
        java.util.Date dd = new java.util.Date(d.getTime() + 8 * 3600 * 1000);
        Assert.assertEquals(22, dd.getHours());
    }

}
