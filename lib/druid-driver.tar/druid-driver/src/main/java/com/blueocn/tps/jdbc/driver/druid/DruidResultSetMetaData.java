package com.blueocn.tps.jdbc.driver.druid;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.blueocn.tps.jdbc.driver.wrap.ResultSetMetaDataWrap;

public class DruidResultSetMetaData extends ResultSetMetaDataWrap {

    private static final Logger logger = LoggerFactory.getLogger(DruidResultSetMetaData.class);

    private JSONObject   object;
    private List<String> header;



    public DruidResultSetMetaData(List<String> header, JSONObject object) {
        this.object = object;
        this.header = header;
        if (logger.isDebugEnabled()) {
            Map<Integer, String> headerMap = new HashMap<Integer, String>();
            for (int i = 0; i < header.size(); i++) {
                String head = header.get(i);
                headerMap.put(i, head);
            }
            logger.debug("headers:" + JSON.toJSONString(headerMap, true));
        }
    }

    @Override
    public String getColumnClassName(int column) throws SQLException {
        return object.get(header.get(column - 1)).getClass().getName();
    }

    @Override
    public int getColumnCount() throws SQLException {
        if (object == null)
            return 0;
        return object.size();
    }

    @Override
    public String getColumnLabel(int column) throws SQLException {
        return getColumnName(column);
    }

    @Override
    public String getColumnName(int column) throws SQLException {
        return header.get(column - 1);
    }

    @Override
    public int getColumnType(int column) throws SQLException {
        if (header.size() > column - 1) {
            Object obj = object.get(header.get(column - 1));

            if (logger.isDebugEnabled()) {
                Map<String, Object> jsonMap = new HashMap<String, Object>();
                jsonMap.put("index", column);
                if (header.size() > column - 1) {
                    jsonMap.put("name", header.get(column - 1));
                }
                jsonMap.put("result", obj);
                jsonMap.put("type", obj.getClass());

                logger.debug("dao framwork get columnType:\n" + JSON.toJSONString(jsonMap, true));
            }
            if (obj instanceof String) {
                return Types.VARCHAR;
            } else if (obj instanceof Double || obj instanceof BigDecimal) {
                return Types.DOUBLE;
            } else if (obj instanceof Float) {
                return Types.FLOAT;
            } else if (obj instanceof Integer || obj instanceof Short) {
                return Types.INTEGER;
            } else if (obj instanceof Long) {
                return Types.BIGINT;
            } else if (obj instanceof Date) {
                return Types.DATE;
            } else if (obj instanceof Timestamp) {
                return Types.TIMESTAMP;
            } else if (obj instanceof Character) {
                return Types.CHAR;
            } else if (obj instanceof Boolean) {
                return Types.BOOLEAN;
            }
        }

        throw new RuntimeException("not found column:{index:" + column + ",headers:" + Arrays.toString(header.toArray()) + "}");
    }


}
