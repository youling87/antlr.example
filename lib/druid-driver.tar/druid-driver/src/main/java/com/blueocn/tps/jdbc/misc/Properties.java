package com.blueocn.tps.jdbc.misc;

public class Properties extends java.util.Properties{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Properties(){}
	
	
	private static Properties instants=new Properties();
	
	
	static{
		instants.put("java.sql.driver.majorVersion", 1);
		instants.put("java.sql.driver.minorVersion", 1);
	}
	
	public static final Properties getInstants(){
		return instants;
	}
	
}
