package com.blueocn.tps.jdbc.driver.druid;

import com.blueocn.tps.jdbc.driver.wrap.StatementWrap;

public class DruidStatement extends StatementWrap {

}
