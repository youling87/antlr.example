package com.blueocn.tps.jdbc.driver.druid;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.blueocn.druid.SqlRunner;
import com.blueocn.tps.jdbc.driver.wrap.ConnectionWrap;

public class DruidConnection extends ConnectionWrap {

    private Properties properties;

    private SqlRunner  sqlRunner;

    public DruidConnection(Properties properties) {
        this.properties = properties;
        this.sqlRunner = new SqlRunner(properties);
        StringBuilder builder = new StringBuilder("http://");
        if (properties.containsKey("host")) {
            builder.append(properties.get("host"));
        }
        if (properties.containsKey("port")) {
            builder.append(":").append(properties.get("port"));
        }
        builder.append("/");

        if (properties.containsKey("dbname")) {
            builder.append(properties.get("dbname"));
        }
        properties.put("url", builder.toString());
    }

    public Object query(String sql) {
        System.out.println(sql);
        return this.sqlRunner.queryObject(sql);
    }


    @Override
    public PreparedStatement prepareStatement(String sql) throws SQLException {
        return new DruidPreparedStatement(sql, this, properties);
    }
    
    @Override
    public Statement createStatement() throws SQLException {
        return new DruidPreparedStatement(null, this, properties);
    }

    @Override
    public void close() throws SQLException {
        try {
            this.sqlRunner.close();
        } catch (Exception e) {
            throw new SQLException(e);
        }
    }

}
