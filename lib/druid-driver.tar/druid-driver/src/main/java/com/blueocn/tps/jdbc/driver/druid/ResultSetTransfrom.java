package com.blueocn.tps.jdbc.driver.druid;

import java.sql.Date;
import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

public class ResultSetTransfrom {


    public static final JSONArray parser(JSONArray array) {
        JSONArray returnVal = new JSONArray();
        try {
            // TODO:不划分结构进行merge
            for (Object object : array) {
                if (object instanceof JSONObject) {
                    JSONObject jsonObject = (JSONObject) object;
                    String timeStamp = jsonObject.getString("timestamp");
                    if (StringUtils.isNotBlank(timeStamp)) {
                        java.util.Date d = DateFormatUtils.ISO_DATETIME_FORMAT.parse(timeStamp);
                        Date date = new Date(d.getTime() + 8 * 3600 * 1000);

                        // JSONArray result = jsonObject.getJSONArray("result");
                        Object obj = jsonObject.get("result");
                        if (obj != null) {
                            if (obj instanceof JSONObject) {
                                JSONObject result = (JSONObject) obj;
                                result.put("timestamp", date);
                                returnVal.add(result);
                            } else if (obj instanceof JSONArray) {
                                JSONArray result = (JSONArray) obj;
                                for (int i = 0; i < result.size(); i++) {
                                    result.getJSONObject(i).put("timestamp", date);
                                }
                                returnVal.addAll(result);
                            }
                        } else {
                            // group by
                            JSONObject event = jsonObject.getJSONObject("event");
                            event.put("timestamp", date);
                            if (event != null) {
                                returnVal.add(event);
                            }
                        }
                    } else {
                        returnVal.add(object);
                    }

                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return returnVal;
    }


}
