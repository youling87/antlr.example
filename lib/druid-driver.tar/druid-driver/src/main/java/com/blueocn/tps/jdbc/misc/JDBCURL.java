package com.blueocn.tps.jdbc.misc;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.StringTokenizer;

/**
 * JDBC URL的抽象
 * 
 * @author 964700108@qq.com
 * 
 * @version 1.0
 *
 */
public class JDBCURL {
    private String  prototype;

    private String  majorProtocol;

    private String  minorProtocol;

    private String  hosts;

    private Integer port;

    private String  dbname;

    private String  queryString;

    /**
     * 对JDBC URL的封装解析,格式错误将抛出<see>MalformedURLException</see>
     * 
     * @param url
     * @throws MalformedURLException 错误的URL格式 jdbc:子协议//hosts[:port]/dbname?queryString
     */
    public JDBCURL(String url) throws MalformedURLException {
        int len = 0;
        if (url != null) {
            int paramsIndex = -1;
            if ((paramsIndex = url.indexOf("?")) != -1) {
                len = 1;
                if (paramsIndex < url.length()) {
                    this.queryString = url.substring(paramsIndex + 1);
                    url = url.substring(0, paramsIndex);
                } else {
                    url = url.substring(0, paramsIndex);
                }
            }
            this.prototype = url;

            char[] charArray = prototype.toCharArray();
            int index = 0;
            for (; index < charArray.length;) {
                char ch = charArray[index++];
                if (ch == ':') {
                    this.majorProtocol = new String(Arrays.copyOfRange(charArray, 0, index - 1));
                    break;
                }
            }
            int marke = index;
            for (; index < charArray.length;) {
                char ch = charArray[index++];
                if (ch == '/' && charArray[index] == '/') {
                    this.minorProtocol = new String(Arrays.copyOfRange(charArray, marke, index - 1));
                    index++;
                    break;
                }
            }
            marke = index;
            for (; index < charArray.length;) {
                char ch = charArray[index++];
                if (ch == '/') {
                    String host = new String(Arrays.copyOfRange(charArray, marke, index - 1));
                    if ((marke = host.indexOf(":")) != -1) {
                        this.hosts = host.substring(0, marke++);
                        this.port = Integer.valueOf(host.substring(marke));
                    } else {
                        this.hosts = host;
                        this.port = 80;
                    }
                    break;
                }
            }

            this.dbname = new String(Arrays.copyOfRange(charArray, index, charArray.length - len));
        }
    }

    /**
     * 获取jdbc主协议 常量JDBC
     * 
     * @author 964700108@qq.com
     * @return
     */
    public String getMajorProtocol() {
        return this.majorProtocol;
    }

    /**
     * 获取JDBC次协议 由框架进行制定命名 如:mysql,oneapm 等
     * 
     * @author 964700108@qq.com
     * @return
     */
    public String getMinorProtocol() {
        return this.minorProtocol;
    }

    /**
     * 获取JDBC链接的Host 如: db-server,127.0.0.1
     * 
     * @author 964700108@qq.com
     * @return
     */
    public String getHost() {
        return this.hosts;
    }

    /**
     * 获取JDBC链接的端口 如: 3366,8448
     * 
     * @author 964700108@qq.com
     * @return
     */
    public Integer getPort() {
        return this.port;
    }

    /**
     * 获取JDBC连接的DBName
     * 
     * @author 964700108@qq.com
     * @return
     */
    public String getDBName() {
        return this.dbname;
    }

    /**
     * 获取JDBC携带的参数
     * 
     * @author 964700108@qq.com
     * @return
     */
    public String getQueryStr() {
        return this.queryString;
    }

}
