package com.pihui.nbsp.operands.primitive;

import com.pihui.nbsp.operands.Oprand;

public abstract interface PrimitiveOprand
extends Oprand
{
public abstract String getValue();
}
