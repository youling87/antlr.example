package com.pihui.nbsp.operands.binary;

import com.pihui.nbsp.operands.Oprand;

public class AddOprand
extends BinaryOprand
{
public AddOprand(Oprand left, Oprand right)
{
  super(left, right, "+");
}
}

