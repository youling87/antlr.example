package com.pihui.nbsp.operands.binary;

import com.pihui.nbsp.operands.Oprand;


public class QuotientOprand
extends BinaryOprand
{
public QuotientOprand(Oprand left, Oprand right)
{
  super(left, right, "quotient");
}
}
