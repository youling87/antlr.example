package com.pihui.nbsp.operands.binary;

import com.pihui.nbsp.operands.Oprand;

public class DividOprand
extends BinaryOprand
{
public DividOprand(Oprand left, Oprand right)
{
  super(left, right, "/");
}
}
