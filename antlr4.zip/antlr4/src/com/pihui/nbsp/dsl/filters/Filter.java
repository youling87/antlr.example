package com.pihui.nbsp.dsl.filters;

public abstract interface Filter
{
  public abstract String getType();
}
