package com.pihui.nbsp.parser.function;

import com.pihui.nbsp.operands.CountOprand;
import com.pihui.nbsp.operands.Oprand;

class CountFuncation
implements Funcation
{
public Object call(Object... args)
{
  return new CountOprand("count", (Oprand)args[0]);
}
}
