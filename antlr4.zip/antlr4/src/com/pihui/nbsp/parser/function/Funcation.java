package com.pihui.nbsp.parser.function;
public abstract interface Funcation
{
  public abstract Object call(Object... paramVarArgs);
}
